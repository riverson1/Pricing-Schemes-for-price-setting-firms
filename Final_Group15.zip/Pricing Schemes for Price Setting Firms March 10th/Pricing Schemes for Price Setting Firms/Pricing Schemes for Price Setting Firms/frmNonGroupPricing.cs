﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Pricing_Schemes_for_Price_Setting_Firms
{
    public partial class frmNonGroupPricing : Form
    {   
        decimal q1 = 0;
        decimal q2 = 0;
        decimal a1 = 0;
        decimal a2 = 0;
        decimal mC = 0;

        int shameCounter = 0;
        string[] errorTitles = { "Oopsies", "Ouch!", "Whoopsie-Daisies!", "uh-oh!", "Yikes!", "Shoot!", "Crud!", "Dang!", "Oh heck!", "Rats!" };


        public frmNonGroupPricing()
        {
            InitializeComponent();
            txtQH1.Text = frmMainMenu.qOB1;
            txtAH1.Text = frmMainMenu.hB1;
            txtQH2.Text = frmMainMenu.qOB2;
            txtAH2.Text = frmMainMenu.hB2;
            txtMC.Text = frmMainMenu.mC;
        }


        //Identical Validation method from main menu
        public bool DoesNotContainDecimal(System.Windows.Forms.TextBox textBox, string name)
        {
            if (!textBox.Text.Contains("."))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be a whole number.", errorTitles[1]);
                textBox.SelectionStart = 0;
                textBox.SelectionLength = textBox.Text.Length;
                textBox.Focus();
                textBox.Text = "";
                //clears the textbox
                txtOptimalPrice.Text = "";
                txtProfit1.Text = "";
                txtProfit2.Text = "";
                txtProfit.Text = "";

                return false;

            }
        }
        //Event based exeption handling is nearly identical to main menu
        //The changes are specified in TextChangedQH
        private void TextChangedQH1(object sender, EventArgs e)
        {
            if (txtQH1.Text != "")
            {
                try
                {
                    decimal test = Convert.ToDecimal(txtQH1.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values", errorTitles[7]);
                    txtQH1.Text = "";
                    shameCounter++;
                }

                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtQH1.Text = "";
                    shameCounter++;
                }
                finally
                {
                    //Clears values in results textbox
                    //identical for every TextChanged and Leave event
                    txtOptimalPrice.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
            }
        }
        private void TextChangedAH1(object sender, EventArgs e)
        {
            if (txtAH1.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH1.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[7]);
                    txtAH1.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtAH1.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
        }
        private void TextChangedQH2(object sender, EventArgs e)
        {
            if (txtQH2.Text != "")
            {
                try
                {
                    decimal test = Convert.ToDecimal(txtQH2.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values", errorTitles[7]);
                    txtQH2.Text = "";
                    shameCounter++;
                }

                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtQH2.Text = "";
                    shameCounter++;
                }
                finally
                {
                    //Clears values in results textbox
                    //identical for every TextChanged and Leave event
                    txtOptimalPrice.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
            }
        }
        private void TextChangedAH2(object sender, EventArgs e)
        {
            if (txtAH2.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH2.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[7]);
                    txtAH2.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtAH2.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
        }
        private void TextChangedMC(object sender, EventArgs e)
        {
            if (txtMC.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtMC.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[7]);
                    txtMC.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtMC.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
        }
        private void LeaveQH1(object sender, EventArgs e)
        {
            if (txtQH1.Text != "")
                try
                {
                    DoesNotContainDecimal(txtQH1, "Quantity of Buyers");
                    if (txtQH1.Text != "")
                    {
                        decimal test = Convert.ToDecimal(txtQH1.Text);
                        decimal zeroTest = 1 / test;
                    }
                }
                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtQH1.Text = "";
                    txtQH1.Focus();
                    shameCounter++;
                }
                finally
                {
                }
        }
        private void LeaveAH1(object sender, EventArgs e)
        {
            if (txtAH1.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH1.Text);
                    decimal zeroTest = 1 / test;
                }

                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtAH1.Text = "";
                    txtAH1.Focus();
                    shameCounter++;
                }

                finally
                {
                }
        }
        private void LeaveQH2(object sender, EventArgs e)
        {
            if (txtQH2.Text != "")
                try
                {
                    DoesNotContainDecimal(txtQH2, "Quantity of Buyers");
                    if (txtQH2.Text != "")
                    {
                        decimal test = Convert.ToDecimal(txtQH2.Text);
                        decimal zeroTest = 1 / test;
                    }
                }
                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtQH2.Text = "";
                    txtQH2.Focus();
                    shameCounter++;
                }
                finally
                {
                }
        }
        private void LeaveAH2(object sender, EventArgs e)
        {
            if (txtAH2.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH2.Text);
                    decimal zeroTest = 1 / test;
                }

                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtAH2.Text = "";
                    txtAH2.Focus();
                    shameCounter++;
                }

                finally
                {
                }
        }



        private void KinkedDemandCurve()
        {
            //create variables we will use in calculation
            //Slope for demand curves
            decimal b1 = a1 / q1;
            decimal b2 = a2 / q2;
            //slope of marginal revenue
            decimal mRB1 = 2 * b1;
            decimal mRB2 = 2 * b2;
            //General optimal level of output
            decimal qOpt1 = (a1 - mC) / mRB1;
            decimal qOpt2 = (a2 - mC) / mRB2;
            //General optimal level of Price
            decimal pOpt1 = a1 - (b1 * qOpt1);
            decimal pOpt2 = a2 - (b2 * qOpt2);
            //General profit
            decimal profit1 = (((pOpt1 - mC) * Math.Abs(qOpt1)));
            decimal profit2 = (((pOpt2 - mC) * Math.Abs(qOpt2)));
            //To show group will not buy
            decimal zero = 0;
            //combine buyers for lower demand
            decimal sOB = q1 + q2;

            if (a2>a1)
            {
                //There is a kink in this demand curve that bows in

                //find Q(kink) with a y value of a1
                decimal qK = (a2 - a1)/b2;
                //The slope of that lower bound:
                decimal bS = (a1) / (sOB - qK);
                //slope of MR
                decimal mRBS = 2 * bS;
                
                //There is a new slope between Qk and the sum of buyers
                //The demand curve before the kink spans from a2 to a1
                //We must now find the Y intercept for the lower part of the kink to functionally create the kink
                //shift a1 from y intercept to Q(kink), find the new shifted y intercept (shyft) for the lower bound of the  kinked demand 
                //Qk = shyft - (b1 * a1)
                //Qk + (b1*a1) = shyft
                decimal shyft = a1 + (bS*qK);
                //we now have the upper and lower bound for the kinked demand
                //upper: Q=a2-(b2*p)
                //lower: Q=Shyft-(b1*p)
                //MR has already be declared above; those equations are
                //upper: MR2=a2-(MBR2*Q)
                //lower: MR1=Shyft-(MBR1*Q)

                //for finding optimal quantity with the kinked demand curve
                //when MC is greater than a1, use group 2 demand
                //When MC is less than a1, use lower bound
                if (mC >= a1)
                { 
                    
                    //see equations in the method  
                    txtOptimalPrice.Text = pOpt2.ToString("c");
                    //because this is the upper bound, calculate profit for only group 2's demand
                    txtProfit1.Text = zero.ToString("c");
                    txtProfit2.Text = profit2.ToString("c");
                    txtProfit.Text = profit2.ToString("c");


                }
                else
                {
                    //qOpt1=(shyft-MC)/MRB1
                    decimal qOpt = (shyft-mC)/mRBS;
                    decimal pOpt = shyft - (bS * qOpt);
                    txtOptimalPrice.Text = pOpt.ToString("c");


                    //find the quantity sold at pOpt for each group's demand curve
                    decimal qA = (a1 - pOpt)/b1;
                    decimal qB = (a2 - pOpt)/b2;
                    decimal profitA = ((pOpt - mC) * Math.Abs(qA));
                    decimal profitB = ((pOpt - mC) * Math.Abs(qB));
                    txtProfit1.Text = profitA.ToString("c");
                    txtProfit2.Text = profitB.ToString("c");
                    txtProfit.Text = (profitA+profitB).ToString("c");
                }
                

            }
            else if(a1> a2)
            {
                //a1 is the y intercept
                //find Q(Kink) with a y value of a2
                //repeat steps above
                decimal qK = (a1 - a2)/b1;
                decimal bS = (a2) / (sOB - qK);
                decimal shyft = a2 + (qK*bS);
                decimal mRBS = 2 * bS;

                if (mC >= a2)
                {
                    txtOptimalPrice.Text = pOpt1.ToString("c");
                    txtProfit2.Text = zero.ToString("c");
                    txtProfit1.Text = profit1.ToString("c");
                    txtProfit.Text= profit1.ToString("c");
                }
                else
                {
                    decimal qOpt = (shyft - mC) / mRBS;
                    decimal pOpt = shyft - (bS * qOpt);
                    txtOptimalPrice.Text = pOpt.ToString("c");

                    decimal qA = (a1 - pOpt) / b1;
                    decimal qB = (a2 - pOpt) / b2;
                    decimal profitA = ((pOpt - mC) * Math.Abs(qA));
                    decimal profitB = ((pOpt - mC) * Math.Abs(qB));
                    txtProfit1.Text = profitA.ToString("c");
                    txtProfit2.Text = profitB.ToString("c");
                    txtProfit.Text = (profitA + profitB).ToString("c");

                }
                
            }
            else
            {
                //find highest number between yint
                decimal a = Math.Max(a2,a1);
                //Combine the quantity of buyers
                decimal q = q1 + q2;
                //slope
                decimal b = a / q;
                //slope of marginal revenue
                decimal mRB = 2 * b;
                //General optimal level of output
                decimal qOpt = (a - mC) / mRB;
                //General optimal level of Price
                decimal pOpt = a - (b * qOpt);
                txtOptimalPrice.Text = pOpt.ToString("c");
                //General profit
                decimal profit = ((pOpt - mC) * Math.Abs(qOpt));
                txtProfit.Text = profit.ToString("c");
                decimal profitA = profit / 2;
                decimal profitB = profit / 2;
                txtProfit1.Text = profitA.ToString("c");
                txtProfit2.Text = profitB.ToString("c");
            }
        }

        private void btnFindOptimalPrice_Click(object sender, EventArgs e)
        {
            try
            {
                mC = Convert.ToDecimal(txtMC.Text);
                a1 = Convert.ToDecimal(txtAH1.Text);
                q1 = Convert.ToDecimal(txtQH1.Text);
                a2 = Convert.ToDecimal(txtAH2.Text);
                q2 = Convert.ToDecimal(txtQH2.Text);
                KinkedDemandCurve();
            }
            catch (FormatException)
            {
                MessageBox.Show("Null value(s), Please stop trying to break this application :(", "Quit that!");
                txtQH1.Text = "";
                txtQH2.Text = "";
                txtAH1.Text = "";
                txtAH2.Text = "";
                txtMC.Text = "";
                txtOptimalPrice.Text = "";
                txtProfit1.Text = "";
                txtProfit2.Text = "";
                txtProfit.Text = "";
                txtQH1.Focus();
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("That was a close one! You must have entered a zero and hit enter. We see what you did there.", "Sneaky! ( ͡° ͜ʖ ͡°)");
                txtQH1.Text = "";
                txtQH2.Text = "";
                txtAH1.Text = "";
                txtAH2.Text = "";
                txtMC.Text = "";
                txtOptimalPrice.Text = "";
                txtProfit1.Text = "";
                txtProfit2.Text = "";
                txtProfit.Text = "";
                txtQH1.Focus();

            }
            finally
            {
                DoesNotContainDecimal(txtQH1, "quantity of buyers");
                DoesNotContainDecimal(txtQH2, "quantity of buyers");
            }
        }    
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtQH1.Text = "";
            txtQH2.Text = "";
            txtAH1.Text = "";
            txtAH2.Text = "";
            txtMC.Text = "";
            txtOptimalPrice.Text = "";
            txtProfit1.Text = "";
            txtProfit2.Text = "";
            txtProfit.Text = "";

        } 
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
