﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pricing_Schemes_for_Price_Setting_Firms
{
    public partial class frmMonopolisticPricing : Form
    {
        //important class varables, namely for the calculate method
        decimal q;
        decimal a;
        decimal mC;
        //class variables to call the text from the main menu
        string zQOB1 = frmMainMenu.qOB1;
        string zQOB2 = frmMainMenu.qOB2;
        string zHB1 = frmMainMenu.hB1;
        string zHB2 = frmMainMenu.hB2;
        string zMC = frmMainMenu.mC;
        //class variables for error messages
        int shameCounter = 0;
        string[] errorTitles = { "Oopsies", "Ouch!", "Whoopsie-Daisies!", "uh-oh!", "Yikes!", "Shoot!", "Crud!", "Dang!", "Oh heck!", "Rats!" };



        public frmMonopolisticPricing()
        {
            InitializeComponent();
            Aggregate();
           
        }

        //Identical Validation method from main menu
        public bool DoesNotContainDecimal(System.Windows.Forms.TextBox textBox, string name)
        {
            if (!textBox.Text.Contains("."))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be a whole number.", errorTitles[1]);
                textBox.SelectionStart = 0;
                textBox.SelectionLength = textBox.Text.Length;
                textBox.Focus();
                textBox.Text = "";
                //clears the textbox
                txtOptimalPrice.Text = "";
                txtProfit.Text = "";

                return false;

            }
        }
        //Event based exeption handling is nearly identical to main menu
        //The changes are specified in TextChangedQH
        private void TextChangedQH(object sender, EventArgs e)
        {
            if (txtQH.Text != "")
            {
                try
                {
                    decimal test = Convert.ToDecimal(txtQH.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values", errorTitles[7]);
                    txtQH.Text = "";
                    shameCounter++;
                }
                
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtQH.Text = "";
                    shameCounter++;
                }
                finally
                {
                    //Clears values in results textbox
                    //identical for every TextChanged and Leave event
                    txtOptimalPrice.Text = "";
                    txtProfit.Text = "";
                }
            }
        }
        private void TextChangedAH(object sender, EventArgs e)
        {
            if (txtAH.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[7]);
                    txtAH.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtAH.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice.Text = "";
                    txtProfit.Text = "";
                }
        }
        private void TextChangedMC(object sender, EventArgs e)
        {
            if (txtMC.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtMC.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[7]);
                    txtMC.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtMC.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice.Text = "";
                    txtProfit.Text = "";
                }
        }
        private void LeaveQH(object sender, EventArgs e)
        {
            if (txtQH.Text != "")
                try
                {
                    DoesNotContainDecimal(txtQH, "Quantity of Buyers");
                    if (txtQH.Text != "")
                    {
                        decimal test = Convert.ToDecimal(txtQH.Text);
                        decimal zeroTest = 1 / test;
                    }
                }
                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtQH.Text = "";
                    
                    txtQH.Focus();
                    shameCounter++;
                }
                finally
                {
                }
        }
        private void LeaveAH(object sender, EventArgs e)
        {
            if (txtAH.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH.Text);
                    decimal zeroTest = 1 / test;
                }

                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtAH.Text = "";
                    txtAH.Focus();
                    shameCounter++;
                }

                finally
                {
                }
        }
       

        //The Aggregate method exists to combine the values of the two groups from the main menu to make an aggregate demand equation
        private void Aggregate()
        {
            //The method will run if all of the parameters in the main menu are not null
            if ((zQOB1 != "") && (zQOB2 != "") && (zHB1 != "") && (zHB2 != "") && (zMC != ""))
            { 
                decimal qH1 = Convert.ToDecimal(zQOB1);
                decimal qH2 = Convert.ToDecimal(zQOB2);
                //method adds the two quanties of buyers together
                decimal qHA = qH1 + qH2;
                decimal ah1 = Convert.ToDecimal(zHB1);
                decimal ah2 = Convert.ToDecimal(zHB2);
                //method chooses the higher number between the highest buyer
                decimal aHA = Math.Max(ah1 ,ah2);
                //the new values then fill the text boxes
                txtQH.Text = Convert.ToString(qHA);
                txtAH.Text = Convert.ToString(aHA);
                txtMC.Text = zMC;
            }
        }

        //Method to calculate the values in the text box and output the results
        private void Calculate()
        {
            //slope for demand equation
            decimal b = a / q;
            
            //slope of marginal revenue equation
            decimal mRB = 2 * b;

            //General optimal level of output
            decimal qOpt = (a - mC) / mRB;
            
            //General optimal level of Price
            decimal pOpt = a - (b * qOpt);
            txtOptimalPrice.Text = pOpt.ToString("c");

            //General profit
            decimal profit = ((pOpt - mC) * Math.Abs(qOpt));
            txtProfit.Text = profit.ToString("c");
        }

        //event to run calculate method
        private void btnFindOptimalPrice_Click(object sender, EventArgs e)
        {
            //one more check to make sure that when the user hits enter they did not add a decimal at the last minute
            
            //we need to check for null and zero one more time to make sure the user did not enter 0 and press enter
            try
            {
                //convert string of values in the text boxes to decimal
                mC = Convert.ToDecimal(txtMC.Text);
                a = Convert.ToDecimal(txtAH.Text);
                q = Convert.ToDecimal(txtQH.Text);
                //method to run calculation
                Calculate();
            }
            catch (FormatException)
            {
                MessageBox.Show("Null value(s), Please stop trying to break this application :(", "Quit that!");
                txtQH.Text = "";
                txtAH.Text = "";
                txtMC.Text = "";
                txtQH.Focus();
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("That was a close one! You must have entered a zero and hit enter. We see what you did there.", "Sneaky! ( ͡° ͜ʖ ͡°)");
                txtQH.Text = "";
                txtAH.Text = "";
                txtMC.Text = "";
                txtQH.Focus();

            }
            finally
            { 
                DoesNotContainDecimal(txtQH, "quantity of buyers");
            }
        }

        //clears text boxes
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtQH.Text = "";
            txtAH.Text = "";
            txtMC.Text = "";
            txtOptimalPrice.Text = "";
            txtProfit.Text = "";
        }

        //exits form back to main menu
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
