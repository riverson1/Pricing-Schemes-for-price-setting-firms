﻿namespace Pricing_Schemes_for_Price_Setting_Firms
{
    partial class frmMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBlockPricing = new System.Windows.Forms.Button();
            this.btnGroupPricing = new System.Windows.Forms.Button();
            this.btnMenuPricing = new System.Windows.Forms.Button();
            this.btnPersonalizedPricing = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnLeave = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnMonopolisticPricing = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnProfitComparison = new System.Windows.Forms.Button();
            this.txtAH2 = new System.Windows.Forms.TextBox();
            this.txtQH2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblFMC = new System.Windows.Forms.Label();
            this.txtMC = new System.Windows.Forms.TextBox();
            this.txtAH1 = new System.Windows.Forms.TextBox();
            this.txtQH1 = new System.Windows.Forms.TextBox();
            this.lblHB = new System.Windows.Forms.Label();
            this.lblQOB = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnNonGroupPricing = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBlockPricing
            // 
            this.btnBlockPricing.Location = new System.Drawing.Point(342, 25);
            this.btnBlockPricing.Name = "btnBlockPricing";
            this.btnBlockPricing.Size = new System.Drawing.Size(141, 23);
            this.btnBlockPricing.TabIndex = 12;
            this.btnBlockPricing.Text = "Block Pricing";
            this.btnBlockPricing.UseVisualStyleBackColor = true;
            this.btnBlockPricing.Click += new System.EventHandler(this.btnBlockPricing_Click);
            // 
            // btnGroupPricing
            // 
            this.btnGroupPricing.Location = new System.Drawing.Point(186, 21);
            this.btnGroupPricing.Name = "btnGroupPricing";
            this.btnGroupPricing.Size = new System.Drawing.Size(141, 23);
            this.btnGroupPricing.TabIndex = 8;
            this.btnGroupPricing.Text = "Group Pricing";
            this.btnGroupPricing.UseVisualStyleBackColor = true;
            this.btnGroupPricing.Click += new System.EventHandler(this.btnGroupPricing_Click);
            // 
            // btnMenuPricing
            // 
            this.btnMenuPricing.Location = new System.Drawing.Point(174, 25);
            this.btnMenuPricing.Name = "btnMenuPricing";
            this.btnMenuPricing.Size = new System.Drawing.Size(141, 23);
            this.btnMenuPricing.TabIndex = 11;
            this.btnMenuPricing.Text = "Menu Pricing";
            this.btnMenuPricing.UseVisualStyleBackColor = true;
            this.btnMenuPricing.Click += new System.EventHandler(this.btnMenuPricing_Click);
            // 
            // btnPersonalizedPricing
            // 
            this.btnPersonalizedPricing.Location = new System.Drawing.Point(507, 21);
            this.btnPersonalizedPricing.Name = "btnPersonalizedPricing";
            this.btnPersonalizedPricing.Size = new System.Drawing.Size(141, 23);
            this.btnPersonalizedPricing.TabIndex = 9;
            this.btnPersonalizedPricing.Text = "Two-Part Tariff";
            this.btnPersonalizedPricing.UseVisualStyleBackColor = true;
            this.btnPersonalizedPricing.Click += new System.EventHandler(this.btnPersonalizedPricing_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(231, 50);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(240, 16);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Pricing Schemes for Price Setting Firms";
            // 
            // btnAbout
            // 
            this.btnAbout.Location = new System.Drawing.Point(270, 415);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(141, 23);
            this.btnAbout.TabIndex = 14;
            this.btnAbout.Text = "About";
            this.btnAbout.UseVisualStyleBackColor = true;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // btnLeave
            // 
            this.btnLeave.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnLeave.Location = new System.Drawing.Point(443, 415);
            this.btnLeave.Name = "btnLeave";
            this.btnLeave.Size = new System.Drawing.Size(141, 23);
            this.btnLeave.TabIndex = 15;
            this.btnLeave.Text = "Leave";
            this.btnLeave.UseVisualStyleBackColor = true;
            this.btnLeave.Click += new System.EventHandler(this.btnLeave_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.Location = new System.Drawing.Point(101, 415);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(141, 23);
            this.btnHelp.TabIndex = 13;
            this.btnHelp.Text = "Help!";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // btnMonopolisticPricing
            // 
            this.btnMonopolisticPricing.Location = new System.Drawing.Point(6, 25);
            this.btnMonopolisticPricing.Name = "btnMonopolisticPricing";
            this.btnMonopolisticPricing.Size = new System.Drawing.Size(141, 23);
            this.btnMonopolisticPricing.TabIndex = 10;
            this.btnMonopolisticPricing.Text = "Aggregated Pricing";
            this.btnMonopolisticPricing.UseVisualStyleBackColor = true;
            this.btnMonopolisticPricing.Click += new System.EventHandler(this.btnMonopolisticPricing_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(353, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "-Per Unit Pricing-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "Packaged Pricing:";
            // 
            // btnProfitComparison
            // 
            this.btnProfitComparison.Location = new System.Drawing.Point(271, 245);
            this.btnProfitComparison.Name = "btnProfitComparison";
            this.btnProfitComparison.Size = new System.Drawing.Size(140, 23);
            this.btnProfitComparison.TabIndex = 0;
            this.btnProfitComparison.Text = "Profit Comparison";
            this.btnProfitComparison.UseVisualStyleBackColor = true;
            this.btnProfitComparison.Click += new System.EventHandler(this.btnProfitComparison_Click);
            // 
            // txtAH2
            // 
            this.txtAH2.Location = new System.Drawing.Point(553, 154);
            this.txtAH2.Name = "txtAH2";
            this.txtAH2.Size = new System.Drawing.Size(100, 22);
            this.txtAH2.TabIndex = 5;
            this.txtAH2.TextChanged += new System.EventHandler(this.SaveValuesAH2);
            this.txtAH2.Leave += new System.EventHandler(this.LeaveAH2);
            // 
            // txtQH2
            // 
            this.txtQH2.AcceptsTab = true;
            this.txtQH2.Location = new System.Drawing.Point(553, 106);
            this.txtQH2.Name = "txtQH2";
            this.txtQH2.Size = new System.Drawing.Size(100, 22);
            this.txtQH2.TabIndex = 4;
            this.txtQH2.TextChanged += new System.EventHandler(this.SaveValuesQH2);
            this.txtQH2.Leave += new System.EventHandler(this.LeaveQH2);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(427, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 16);
            this.label4.TabIndex = 51;
            this.label4.Text = "Highest Bidder";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(409, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 16);
            this.label5.TabIndex = 50;
            this.label5.Text = "Quantity of Buyers";
            // 
            // lblFMC
            // 
            this.lblFMC.AutoSize = true;
            this.lblFMC.Location = new System.Drawing.Point(40, 210);
            this.lblFMC.Name = "lblFMC";
            this.lblFMC.Size = new System.Drawing.Size(125, 16);
            this.lblFMC.TabIndex = 49;
            this.lblFMC.Text = "Fixed Marginal Cost";
            // 
            // txtMC
            // 
            this.txtMC.Location = new System.Drawing.Point(182, 204);
            this.txtMC.Name = "txtMC";
            this.txtMC.Size = new System.Drawing.Size(100, 22);
            this.txtMC.TabIndex = 3;
            this.txtMC.TextChanged += new System.EventHandler(this.SaveValuesMC);
            this.txtMC.Leave += new System.EventHandler(this.LeaveMC);
            // 
            // txtAH1
            // 
            this.txtAH1.Location = new System.Drawing.Point(182, 154);
            this.txtAH1.Name = "txtAH1";
            this.txtAH1.Size = new System.Drawing.Size(100, 22);
            this.txtAH1.TabIndex = 2;
            this.txtAH1.TextChanged += new System.EventHandler(this.SaveValuesAH1);
            this.txtAH1.Leave += new System.EventHandler(this.LeaveAH1);
            // 
            // txtQH1
            // 
            this.txtQH1.AcceptsTab = true;
            this.txtQH1.Location = new System.Drawing.Point(182, 106);
            this.txtQH1.Name = "txtQH1";
            this.txtQH1.Size = new System.Drawing.Size(100, 22);
            this.txtQH1.TabIndex = 1;
            this.txtQH1.TextChanged += new System.EventHandler(this.SaveValuesQH1);
            this.txtQH1.Leave += new System.EventHandler(this.LeaveQH1);
            // 
            // lblHB
            // 
            this.lblHB.AutoSize = true;
            this.lblHB.Location = new System.Drawing.Point(69, 157);
            this.lblHB.Name = "lblHB";
            this.lblHB.Size = new System.Drawing.Size(96, 16);
            this.lblHB.TabIndex = 48;
            this.lblHB.Text = "Highest Bidder";
            // 
            // lblQOB
            // 
            this.lblQOB.AutoSize = true;
            this.lblQOB.Location = new System.Drawing.Point(51, 109);
            this.lblQOB.Name = "lblQOB";
            this.lblQOB.Size = new System.Drawing.Size(114, 16);
            this.lblQOB.TabIndex = 47;
            this.lblQOB.Text = "Quantity of Buyers";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(472, 203);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(121, 23);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear Values";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnNonGroupPricing
            // 
            this.btnNonGroupPricing.Location = new System.Drawing.Point(12, 21);
            this.btnNonGroupPricing.Name = "btnNonGroupPricing";
            this.btnNonGroupPricing.Size = new System.Drawing.Size(141, 23);
            this.btnNonGroupPricing.TabIndex = 7;
            this.btnNonGroupPricing.Text = "Non-Group Pricing";
            this.btnNonGroupPricing.UseVisualStyleBackColor = true;
            this.btnNonGroupPricing.Click += new System.EventHandler(this.btnNonGroupPricing_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnNonGroupPricing);
            this.groupBox1.Controls.Add(this.btnGroupPricing);
            this.groupBox1.Controls.Add(this.btnPersonalizedPricing);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Location = new System.Drawing.Point(12, 284);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(673, 125);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btnMenuPricing);
            this.groupBox2.Controls.Add(this.btnBlockPricing);
            this.groupBox2.Location = new System.Drawing.Point(165, 56);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(502, 63);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnMonopolisticPricing);
            this.groupBox3.Location = new System.Drawing.Point(6, 56);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(152, 63);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(316, 16);
            this.label2.TabIndex = 52;
            this.label2.Text = "Made by Robert Iverson, William Allen, and Ravi Ath";
            // 
            // frmMainMenu
            // 
            this.AcceptButton = this.btnProfitComparison;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnLeave;
            this.ClientSize = new System.Drawing.Size(697, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtAH2);
            this.Controls.Add(this.txtQH2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblFMC);
            this.Controls.Add(this.txtMC);
            this.Controls.Add(this.txtAH1);
            this.Controls.Add(this.txtQH1);
            this.Controls.Add(this.lblHB);
            this.Controls.Add(this.lblQOB);
            this.Controls.Add(this.btnProfitComparison);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.btnLeave);
            this.Controls.Add(this.btnAbout);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmMainMenu";
            this.Text = "Main Menu";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBlockPricing;
        private System.Windows.Forms.Button btnGroupPricing;
        private System.Windows.Forms.Button btnMenuPricing;
        private System.Windows.Forms.Button btnPersonalizedPricing;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.Button btnLeave;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Button btnMonopolisticPricing;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnProfitComparison;
        private System.Windows.Forms.TextBox txtAH2;
        private System.Windows.Forms.TextBox txtQH2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblFMC;
        private System.Windows.Forms.TextBox txtMC;
        private System.Windows.Forms.TextBox txtAH1;
        private System.Windows.Forms.TextBox txtQH1;
        private System.Windows.Forms.Label lblHB;
        private System.Windows.Forms.Label lblQOB;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnNonGroupPricing;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
    }
}

