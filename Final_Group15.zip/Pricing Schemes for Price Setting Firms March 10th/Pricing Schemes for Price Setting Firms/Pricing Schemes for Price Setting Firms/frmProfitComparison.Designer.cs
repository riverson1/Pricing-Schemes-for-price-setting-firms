﻿namespace Pricing_Schemes_for_Price_Setting_Firms
{
    partial class frmProfitComparison
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtAH2 = new System.Windows.Forms.TextBox();
            this.txtQH2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFMC = new System.Windows.Forms.Label();
            this.txtMC = new System.Windows.Forms.TextBox();
            this.txtAH1 = new System.Windows.Forms.TextBox();
            this.txtQH1 = new System.Windows.Forms.TextBox();
            this.lblHB = new System.Windows.Forms.Label();
            this.lblQOB = new System.Windows.Forms.Label();
            this.txtNPD = new System.Windows.Forms.TextBox();
            this.txtTD = new System.Windows.Forms.TextBox();
            this.txtSD = new System.Windows.Forms.TextBox();
            this.txtFD = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(421, 254);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(128, 23);
            this.btnCalculate.TabIndex = 0;
            this.btnCalculate.Text = "Calculate Profit";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtAH2
            // 
            this.txtAH2.Location = new System.Drawing.Point(616, 123);
            this.txtAH2.Name = "txtAH2";
            this.txtAH2.Size = new System.Drawing.Size(100, 22);
            this.txtAH2.TabIndex = 4;
            this.txtAH2.TextChanged += new System.EventHandler(this.ChangeTextAH2);
            this.txtAH2.Leave += new System.EventHandler(this.LeaveAH2);
            // 
            // txtQH2
            // 
            this.txtQH2.AcceptsTab = true;
            this.txtQH2.Location = new System.Drawing.Point(616, 70);
            this.txtQH2.Name = "txtQH2";
            this.txtQH2.Size = new System.Drawing.Size(100, 22);
            this.txtQH2.TabIndex = 3;
            this.txtQH2.TextChanged += new System.EventHandler(this.ChangeTextQH2);
            this.txtQH2.Leave += new System.EventHandler(this.LeaveQH2);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(490, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 51;
            this.label2.Text = "Highest Bidder";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(472, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 16);
            this.label3.TabIndex = 50;
            this.label3.Text = "Quantity of Buyers";
            // 
            // lblFMC
            // 
            this.lblFMC.AutoSize = true;
            this.lblFMC.Location = new System.Drawing.Point(324, 187);
            this.lblFMC.Name = "lblFMC";
            this.lblFMC.Size = new System.Drawing.Size(125, 16);
            this.lblFMC.TabIndex = 49;
            this.lblFMC.Text = "Fixed Marginal Cost";
            // 
            // txtMC
            // 
            this.txtMC.Location = new System.Drawing.Point(486, 181);
            this.txtMC.Name = "txtMC";
            this.txtMC.Size = new System.Drawing.Size(100, 22);
            this.txtMC.TabIndex = 5;
            this.txtMC.TextChanged += new System.EventHandler(this.ChangeTextMC);
            // 
            // txtAH1
            // 
            this.txtAH1.Location = new System.Drawing.Point(319, 123);
            this.txtAH1.Name = "txtAH1";
            this.txtAH1.Size = new System.Drawing.Size(100, 22);
            this.txtAH1.TabIndex = 2;
            this.txtAH1.TextChanged += new System.EventHandler(this.ChangeTextAH1);
            this.txtAH1.Leave += new System.EventHandler(this.LeaveAH1);
            // 
            // txtQH1
            // 
            this.txtQH1.AcceptsTab = true;
            this.txtQH1.Location = new System.Drawing.Point(319, 67);
            this.txtQH1.Name = "txtQH1";
            this.txtQH1.Size = new System.Drawing.Size(100, 22);
            this.txtQH1.TabIndex = 1;
            this.txtQH1.TextChanged += new System.EventHandler(this.ChangeTextQH1);
            this.txtQH1.Leave += new System.EventHandler(this.LeaveQH1);
            // 
            // lblHB
            // 
            this.lblHB.AutoSize = true;
            this.lblHB.Location = new System.Drawing.Point(186, 129);
            this.lblHB.Name = "lblHB";
            this.lblHB.Size = new System.Drawing.Size(96, 16);
            this.lblHB.TabIndex = 48;
            this.lblHB.Text = "Highest Bidder";
            // 
            // lblQOB
            // 
            this.lblQOB.AutoSize = true;
            this.lblQOB.Location = new System.Drawing.Point(168, 73);
            this.lblQOB.Name = "lblQOB";
            this.lblQOB.Size = new System.Drawing.Size(114, 16);
            this.lblQOB.TabIndex = 47;
            this.lblQOB.Text = "Quantity of Buyers";
            // 
            // txtNPD
            // 
            this.txtNPD.Location = new System.Drawing.Point(29, 358);
            this.txtNPD.Name = "txtNPD";
            this.txtNPD.ReadOnly = true;
            this.txtNPD.Size = new System.Drawing.Size(216, 22);
            this.txtNPD.TabIndex = 53;
            this.txtNPD.TabStop = false;
            // 
            // txtTD
            // 
            this.txtTD.Location = new System.Drawing.Point(264, 358);
            this.txtTD.Name = "txtTD";
            this.txtTD.ReadOnly = true;
            this.txtTD.Size = new System.Drawing.Size(216, 22);
            this.txtTD.TabIndex = 54;
            this.txtTD.TabStop = false;
            // 
            // txtSD
            // 
            this.txtSD.Location = new System.Drawing.Point(502, 358);
            this.txtSD.Name = "txtSD";
            this.txtSD.ReadOnly = true;
            this.txtSD.Size = new System.Drawing.Size(214, 22);
            this.txtSD.TabIndex = 55;
            this.txtSD.TabStop = false;
            // 
            // txtFD
            // 
            this.txtFD.Location = new System.Drawing.Point(731, 358);
            this.txtFD.Name = "txtFD";
            this.txtFD.ReadOnly = true;
            this.txtFD.Size = new System.Drawing.Size(214, 22);
            this.txtFD.TabIndex = 56;
            this.txtFD.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(60, 330);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 16);
            this.label6.TabIndex = 59;
            this.label6.Text = "No Price Discrimination";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(737, 330);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(197, 16);
            this.label7.TabIndex = 60;
            this.label7.Text = "First degree price discrimination";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(277, 330);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(203, 16);
            this.label8.TabIndex = 61;
            this.label8.Text = "Third degree price discrimination";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(499, 330);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(219, 16);
            this.label9.TabIndex = 62;
            this.label9.Text = "Second degree price discrimination";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 393);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 16);
            this.label1.TabIndex = 63;
            this.label1.Text = "Monopolistic pricing";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(324, 393);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 16);
            this.label10.TabIndex = 64;
            this.label10.Text = "Group pricing";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(553, 393);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 16);
            this.label11.TabIndex = 65;
            this.label11.Text = "Menu pricing";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(745, 393);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(189, 16);
            this.label12.TabIndex = 66;
            this.label12.Text = "2-Part Tariff and Bundle pricing";
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Location = new System.Drawing.Point(870, 415);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 67;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(13, 415);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 68;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmProfitComparison
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnBack;
            this.ClientSize = new System.Drawing.Size(965, 450);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtFD);
            this.Controls.Add(this.txtSD);
            this.Controls.Add(this.txtTD);
            this.Controls.Add(this.txtNPD);
            this.Controls.Add(this.txtAH2);
            this.Controls.Add(this.txtQH2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblFMC);
            this.Controls.Add(this.txtMC);
            this.Controls.Add(this.txtAH1);
            this.Controls.Add(this.txtQH1);
            this.Controls.Add(this.lblHB);
            this.Controls.Add(this.lblQOB);
            this.Controls.Add(this.btnCalculate);
            this.Name = "frmProfitComparison";
            this.Text = "Profit Comparison";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtAH2;
        private System.Windows.Forms.TextBox txtQH2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblFMC;
        private System.Windows.Forms.TextBox txtMC;
        private System.Windows.Forms.TextBox txtAH1;
        private System.Windows.Forms.TextBox txtQH1;
        private System.Windows.Forms.Label lblHB;
        private System.Windows.Forms.Label lblQOB;
        private System.Windows.Forms.TextBox txtNPD;
        private System.Windows.Forms.TextBox txtTD;
        private System.Windows.Forms.TextBox txtSD;
        private System.Windows.Forms.TextBox txtFD;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnClear;
    }
}