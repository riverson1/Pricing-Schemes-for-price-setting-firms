﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pricing_Schemes_for_Price_Setting_Firms
{
    public partial class frmGroupPricing : Form
    {
        decimal q1 = 0;
        decimal q2 = 0;
        decimal a1 = 0;
        decimal a2 = 0;
        decimal mC = 0;

        //counter for error message loop
        int shameCounter = 0;
        string[] errorTitles = { "Oopsies", "Ouch!", "Whoopsie-Daisies!", "uh-oh!", "Yikes!", "Shoot!", "Crud!", "Dang!", "Oh heck!", "Rats!" };

        public frmGroupPricing()
        {
            InitializeComponent();
            txtQH1.Text = frmMainMenu.qOB1;
            txtAH1.Text = frmMainMenu.hB1;
            txtQH2.Text = frmMainMenu.qOB2;
            txtAH2.Text = frmMainMenu.hB2;
            txtMC.Text = frmMainMenu.mC;
        }

        //Identical Validation method from main menu
        public bool DoesNotContainDecimal(System.Windows.Forms.TextBox textBox, string name)
        {

            //if (Int32.TryParse(textBox.Text, out int number))
            if (!textBox.Text.Contains("."))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be a whole number.", errorTitles[1]);
                textBox.SelectionStart = 0;
                textBox.SelectionLength = textBox.Text.Length;
                textBox.Focus();
                textBox.Text = "";
                txtOptimalPrice1.Text = "";
                txtOptimalPrice2.Text = "";
                txtProfit1.Text = "";
                txtProfit2.Text = "";
                txtProfit.Text = "";

                return false;

            }
        }

        //Event based exeption handling is nearly identical to main menu
        private void ChangeTextQH1(object sender, EventArgs e)
        {
            if (txtQH1.Text != "")
            {
                try
                {
                    decimal test = Convert.ToDecimal(txtQH1.Text);
                }
               
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values", errorTitles[7]);
                    txtQH1.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtQH1.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice1.Text = "";
                    txtOptimalPrice2.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
            }
        }
        private void ChangeTextAH1(object sender, EventArgs e)
        {
            if (txtAH1.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH1.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[7]);
                    txtAH1.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtAH1.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice1.Text = "";
                    txtOptimalPrice2.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }


        }
        private void ChangeTextQH2(object sender, EventArgs e)
        {

            if (txtQH2.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtQH2.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values", errorTitles[7]);
                    txtQH2.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtQH2.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice1.Text = "";
                    txtOptimalPrice2.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
        }
        private void ChangeTextAH2(object sender, EventArgs e)
        {
            if (txtAH2.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH2.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[7]);
                    txtAH2.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtAH2.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice1.Text = "";
                    txtOptimalPrice2.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
        }
        private void ChangeTextMC(object sender, EventArgs e)
        {
            if (txtMC.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtMC.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[7]);
                    txtMC.Text = "";
                    shameCounter++;
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[7]);
                    txtMC.Text = "";
                    shameCounter++;
                }
                finally
                {
                    txtOptimalPrice1.Text = "";
                    txtOptimalPrice2.Text = "";
                    txtProfit1.Text = "";
                    txtProfit2.Text = "";
                    txtProfit.Text = "";
                }
        }

        private void LeaveQH1(object sender, EventArgs e)
        {
            //we trigger a divide by zero by turning the string into a test variable, then putting that test variable in a denominator

            //we've created a doorway so that you mustn't have a null to proceed to the exception handling
            if (txtQH1.Text != "")
                try
                {
                    DoesNotContainDecimal(txtQH1, "Quantity of Buyers");
                    //we've created another so we can null a violation of the validation while not passing the null value to check for a zero value
                    if (txtQH1.Text != "")
                    {
                        decimal test = Convert.ToDecimal(txtQH1.Text);
                        decimal zeroTest = 1 / test;
                    }
                }
                //we need a format exception exception since tabbing without entering a value will crash the program (null is not a numeric value)
                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtQH1.Text = "";
                    txtQH1.Focus();
                    shameCounter++;
                }
                finally
                {
                }
        }
        private void LeaveAH1(object sender, EventArgs e)
        {
            if (txtAH1.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH1.Text);
                    decimal zeroTest = 1 / test;
                }

                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtAH1.Text = "";
                    txtAH1.Focus();
                    shameCounter++;
                }

                finally
                {
                }
        }
        private void LeaveQH2(object sender, EventArgs e)
        {
            if (txtQH2.Text != "")
                try
                {
                    DoesNotContainDecimal(txtQH2, "Quantity of Buyers");
                    if (txtQH2.Text != "")
                    {
                        decimal test = Convert.ToDecimal(txtQH2.Text);
                        decimal zeroTest = 1 / test;
                    }
                }
                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtQH2.Text = "";
                    txtQH2.Focus();
                    shameCounter++;
                }

                finally
                {
                }
        }
        private void LeaveAH2(object sender, EventArgs e)
        {
            if (txtAH2.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH2.Text);
                    decimal zeroTest = 1 / test;
                }

                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[7]);
                    txtAH2.Text = "";
                    txtAH2.Focus();
                    shameCounter++;
                }

                finally
                {
                }
        }
        private void Calculate()
        {
            //create variables we will use in calculation
            //slope of demand curve
            decimal b1 = a1 / q1;
            decimal b2 = a2 / q2;
            //slope of marginal revenue
            decimal mRB1 = 2 * b1;
            decimal mRB2 = 2 * b2;
            //General optimal level of output
            decimal qOpt1 = (a1 - mC) / mRB1;
            decimal qOpt2 = (a2 - mC) / mRB2;
            //General optimal level of Price, ABS taken in times mC is larger than highest bidder
            decimal pOpt1 = a1 - b1 * qOpt1;
            decimal pOpt2 = a2 - b2 * qOpt2;
            txtOptimalPrice1.Text = pOpt1.ToString("c");
            txtOptimalPrice2.Text = pOpt2.ToString("c");
            //General profit, ABS used to properly show a loss due to mC being larger than highest bidder
            decimal Profit1 = (pOpt1 - mC) * Math.Abs(qOpt1);
            decimal Profit2 = (pOpt2 - mC) * Math.Abs(qOpt2);
            txtProfit1.Text = Profit1.ToString("c");
            txtProfit2.Text = Profit2.ToString("c");
            txtProfit.Text = (Profit1 + Profit2).ToString("c");
        }

        private void btnFindOptimalPrice_Click(object sender, EventArgs e)
        {
            try 
            { 
                mC = Convert.ToDecimal(txtMC.Text);
                a1 = Convert.ToDecimal(txtAH1.Text);
                q1 = Convert.ToDecimal(txtQH1.Text);
                a2 = Convert.ToDecimal(txtAH2.Text);
                q2 = Convert.ToDecimal(txtQH2.Text);
                Calculate();
            }
            catch (FormatException)
            {
                MessageBox.Show("Null value(s), Please stop trying to break this application :(", "Quit that!");
                txtQH1.Text = "";
                txtQH2.Text = "";
                txtAH1.Text = "";
                txtAH2.Text = "";
                txtMC.Text = "";
                txtOptimalPrice1.Text = "";
                txtOptimalPrice2.Text = "";
                txtProfit1.Text = "";
                txtProfit2.Text = "";
                txtProfit.Text = "";
                txtQH1.Focus();
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("That was a close one! You must have entered a zero and hit enter. We see what you did there.", "Sneaky! ( ͡° ͜ʖ ͡°)");
                txtQH1.Text = "";
                txtQH2.Text = "";
                txtAH1.Text = "";
                txtAH2.Text = "";
                txtMC.Text = "";
                txtOptimalPrice1.Text = "";
                txtOptimalPrice2.Text = "";
                txtProfit1.Text = "";
                txtProfit2.Text = "";
                txtProfit.Text = "";
                txtQH1.Focus();

            }
            finally
            {
                DoesNotContainDecimal(txtQH1, "quantity of buyers");
                DoesNotContainDecimal(txtQH2, "quantity of buyers");
            }
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtQH1.Text = "";
            txtAH1.Text = "";
            txtQH2.Text = "";
            txtAH2.Text = "";
            txtMC.Text = "";
            txtOptimalPrice1.Text = "";
            txtOptimalPrice2.Text = "";
            txtProfit1.Text = "";
            txtProfit2.Text = "";
            txtProfit.Text = "";
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();  
        }

       
    }
}
