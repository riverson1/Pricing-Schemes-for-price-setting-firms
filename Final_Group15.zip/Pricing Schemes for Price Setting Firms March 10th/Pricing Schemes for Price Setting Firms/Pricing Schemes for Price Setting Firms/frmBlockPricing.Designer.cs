﻿namespace Pricing_Schemes_for_Price_Setting_Firms
{
    partial class frmBlockPricing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtProfit2 = new System.Windows.Forms.TextBox();
            this.txtProfit1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBundlePrice2 = new System.Windows.Forms.TextBox();
            this.txtBundlePrice1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtOptimalQuantity2 = new System.Windows.Forms.TextBox();
            this.txtAH2 = new System.Windows.Forms.TextBox();
            this.txtQH2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFMC = new System.Windows.Forms.Label();
            this.txtMC = new System.Windows.Forms.TextBox();
            this.txtOptimalQuantity1 = new System.Windows.Forms.TextBox();
            this.btnFindOptimalPrice = new System.Windows.Forms.Button();
            this.txtAH1 = new System.Windows.Forms.TextBox();
            this.txtQH1 = new System.Windows.Forms.TextBox();
            this.lblHB = new System.Windows.Forms.Label();
            this.lblQOB = new System.Windows.Forms.Label();
            this.txtProfit = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Location = new System.Drawing.Point(662, 380);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 8;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(61, 382);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(447, 339);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 16);
            this.label8.TabIndex = 122;
            this.label8.Text = "Estimated Profit Group 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(79, 336);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(150, 16);
            this.label9.TabIndex = 121;
            this.label9.Text = "Estimated Profit Group 1";
            // 
            // txtProfit2
            // 
            this.txtProfit2.Location = new System.Drawing.Point(616, 333);
            this.txtProfit2.Name = "txtProfit2";
            this.txtProfit2.ReadOnly = true;
            this.txtProfit2.Size = new System.Drawing.Size(123, 22);
            this.txtProfit2.TabIndex = 120;
            this.txtProfit2.TabStop = false;
            // 
            // txtProfit1
            // 
            this.txtProfit1.Location = new System.Drawing.Point(263, 330);
            this.txtProfit1.Name = "txtProfit1";
            this.txtProfit1.ReadOnly = true;
            this.txtProfit1.Size = new System.Drawing.Size(132, 22);
            this.txtProfit1.TabIndex = 119;
            this.txtProfit1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(464, 292);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 16);
            this.label6.TabIndex = 118;
            this.label6.Text = "Bundle Price Group 2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(95, 292);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 16);
            this.label7.TabIndex = 117;
            this.label7.Text = "Bundle Price Group 1";
            // 
            // txtBundlePrice2
            // 
            this.txtBundlePrice2.Location = new System.Drawing.Point(616, 289);
            this.txtBundlePrice2.Name = "txtBundlePrice2";
            this.txtBundlePrice2.ReadOnly = true;
            this.txtBundlePrice2.Size = new System.Drawing.Size(100, 22);
            this.txtBundlePrice2.TabIndex = 116;
            this.txtBundlePrice2.TabStop = false;
            // 
            // txtBundlePrice1
            // 
            this.txtBundlePrice1.Location = new System.Drawing.Point(263, 286);
            this.txtBundlePrice1.Name = "txtBundlePrice1";
            this.txtBundlePrice1.ReadOnly = true;
            this.txtBundlePrice1.Size = new System.Drawing.Size(100, 22);
            this.txtBundlePrice1.TabIndex = 115;
            this.txtBundlePrice1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(440, 249);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 16);
            this.label5.TabIndex = 114;
            this.label5.Text = "Optimal  Quantity Group 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(75, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 16);
            this.label4.TabIndex = 113;
            this.label4.Text = "Optimal Quantity Group 1";
            // 
            // txtOptimalQuantity2
            // 
            this.txtOptimalQuantity2.Location = new System.Drawing.Point(616, 246);
            this.txtOptimalQuantity2.Name = "txtOptimalQuantity2";
            this.txtOptimalQuantity2.ReadOnly = true;
            this.txtOptimalQuantity2.Size = new System.Drawing.Size(100, 22);
            this.txtOptimalQuantity2.TabIndex = 112;
            this.txtOptimalQuantity2.TabStop = false;
            // 
            // txtAH2
            // 
            this.txtAH2.AcceptsTab = true;
            this.txtAH2.Location = new System.Drawing.Point(612, 100);
            this.txtAH2.Name = "txtAH2";
            this.txtAH2.Size = new System.Drawing.Size(100, 22);
            this.txtAH2.TabIndex = 5;
            this.txtAH2.TextChanged += new System.EventHandler(this.ChangeTextAH2);
            this.txtAH2.Leave += new System.EventHandler(this.LeaveAH2);
            // 
            // txtQH2
            // 
            this.txtQH2.AcceptsTab = true;
            this.txtQH2.Location = new System.Drawing.Point(612, 46);
            this.txtQH2.Name = "txtQH2";
            this.txtQH2.Size = new System.Drawing.Size(100, 22);
            this.txtQH2.TabIndex = 4;
            this.txtQH2.TextChanged += new System.EventHandler(this.ChangeTextQH2);
            this.txtQH2.Leave += new System.EventHandler(this.LeaveQH2);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(486, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 110;
            this.label2.Text = "Highest Bidder";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(468, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 16);
            this.label3.TabIndex = 109;
            this.label3.Text = "Quantity of Buyers";
            // 
            // lblFMC
            // 
            this.lblFMC.AutoSize = true;
            this.lblFMC.Location = new System.Drawing.Point(93, 156);
            this.lblFMC.Name = "lblFMC";
            this.lblFMC.Size = new System.Drawing.Size(125, 16);
            this.lblFMC.TabIndex = 108;
            this.lblFMC.Text = "Fixed Marginal Cost";
            // 
            // txtMC
            // 
            this.txtMC.AcceptsTab = true;
            this.txtMC.Location = new System.Drawing.Point(241, 153);
            this.txtMC.Name = "txtMC";
            this.txtMC.Size = new System.Drawing.Size(100, 22);
            this.txtMC.TabIndex = 3;
            this.txtMC.TextChanged += new System.EventHandler(this.ChangeTextMC);
            // 
            // txtOptimalQuantity1
            // 
            this.txtOptimalQuantity1.Location = new System.Drawing.Point(263, 243);
            this.txtOptimalQuantity1.Name = "txtOptimalQuantity1";
            this.txtOptimalQuantity1.ReadOnly = true;
            this.txtOptimalQuantity1.Size = new System.Drawing.Size(100, 22);
            this.txtOptimalQuantity1.TabIndex = 107;
            this.txtOptimalQuantity1.TabStop = false;
            // 
            // btnFindOptimalPrice
            // 
            this.btnFindOptimalPrice.Location = new System.Drawing.Point(517, 153);
            this.btnFindOptimalPrice.Name = "btnFindOptimalPrice";
            this.btnFindOptimalPrice.Size = new System.Drawing.Size(169, 23);
            this.btnFindOptimalPrice.TabIndex = 0;
            this.btnFindOptimalPrice.Text = "Find Optimal Price";
            this.btnFindOptimalPrice.UseVisualStyleBackColor = true;
            this.btnFindOptimalPrice.Click += new System.EventHandler(this.btnFindOptimalPrice_Click_1);
            // 
            // txtAH1
            // 
            this.txtAH1.AcceptsTab = true;
            this.txtAH1.Location = new System.Drawing.Point(241, 100);
            this.txtAH1.Name = "txtAH1";
            this.txtAH1.Size = new System.Drawing.Size(100, 22);
            this.txtAH1.TabIndex = 2;
            this.txtAH1.TextChanged += new System.EventHandler(this.ChangeTextAH1);
            this.txtAH1.Leave += new System.EventHandler(this.LeaveAH1);
            // 
            // txtQH1
            // 
            this.txtQH1.AcceptsTab = true;
            this.txtQH1.Location = new System.Drawing.Point(241, 46);
            this.txtQH1.Name = "txtQH1";
            this.txtQH1.Size = new System.Drawing.Size(100, 22);
            this.txtQH1.TabIndex = 1;
            this.txtQH1.TextChanged += new System.EventHandler(this.ChangeTextQH1);
            this.txtQH1.Leave += new System.EventHandler(this.LeaveQH1);
            // 
            // lblHB
            // 
            this.lblHB.AutoSize = true;
            this.lblHB.Location = new System.Drawing.Point(122, 103);
            this.lblHB.Name = "lblHB";
            this.lblHB.Size = new System.Drawing.Size(96, 16);
            this.lblHB.TabIndex = 106;
            this.lblHB.Text = "Highest Bidder";
            // 
            // lblQOB
            // 
            this.lblQOB.AutoSize = true;
            this.lblQOB.Location = new System.Drawing.Point(104, 46);
            this.lblQOB.Name = "lblQOB";
            this.lblQOB.Size = new System.Drawing.Size(114, 16);
            this.lblQOB.TabIndex = 105;
            this.lblQOB.Text = "Quantity of Buyers";
            // 
            // txtProfit
            // 
            this.txtProfit.Location = new System.Drawing.Point(414, 383);
            this.txtProfit.Name = "txtProfit";
            this.txtProfit.ReadOnly = true;
            this.txtProfit.Size = new System.Drawing.Size(100, 22);
            this.txtProfit.TabIndex = 124;
            this.txtProfit.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(315, 389);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 123;
            this.label10.Text = "Total Profit";
            // 
            // frmBlockPricing
            // 
            this.AcceptButton = this.btnFindOptimalPrice;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnBack;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtProfit);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtProfit2);
            this.Controls.Add(this.txtProfit1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtBundlePrice2);
            this.Controls.Add(this.txtBundlePrice1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtOptimalQuantity2);
            this.Controls.Add(this.txtAH2);
            this.Controls.Add(this.txtQH2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblFMC);
            this.Controls.Add(this.txtMC);
            this.Controls.Add(this.txtOptimalQuantity1);
            this.Controls.Add(this.btnFindOptimalPrice);
            this.Controls.Add(this.txtAH1);
            this.Controls.Add(this.txtQH1);
            this.Controls.Add(this.lblHB);
            this.Controls.Add(this.lblQOB);
            this.Controls.Add(this.btnBack);
            this.Name = "frmBlockPricing";
            this.Text = "Block Pricing";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtProfit2;
        private System.Windows.Forms.TextBox txtProfit1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBundlePrice2;
        private System.Windows.Forms.TextBox txtBundlePrice1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtOptimalQuantity2;
        private System.Windows.Forms.TextBox txtAH2;
        private System.Windows.Forms.TextBox txtQH2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblFMC;
        private System.Windows.Forms.TextBox txtMC;
        private System.Windows.Forms.TextBox txtOptimalQuantity1;
        private System.Windows.Forms.Button btnFindOptimalPrice;
        private System.Windows.Forms.TextBox txtAH1;
        private System.Windows.Forms.TextBox txtQH1;
        private System.Windows.Forms.Label lblHB;
        private System.Windows.Forms.Label lblQOB;
        private System.Windows.Forms.TextBox txtProfit;
        private System.Windows.Forms.Label label10;
    }
}