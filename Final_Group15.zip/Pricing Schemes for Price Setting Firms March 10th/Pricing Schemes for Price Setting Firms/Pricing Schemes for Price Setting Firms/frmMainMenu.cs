﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

//Made by Robert Iverson, Concepts and event based exceptions; forms and user experience
//William Allen: Quanitity of Buyers integer validation, for loop Clear Values button,
//errorTitles Array and and if statement to loop through them with the shameCounter
//Ravi Ath, quality control (camel case followed etc) and design

namespace Pricing_Schemes_for_Price_Setting_Firms
{
    //This form functions as the main menu to launch other forms
    public partial class frmMainMenu : Form
    {
        //strings to be used between forms
        public static string qOB1 = "";
        public static string hB1 = "";
        public static string qOB2 = "";
        public static string hB2 = "";
        public static string mC = "";
        /* an explanation of the string variables
         * qOB1: quantity of buyers in group 1
         * hb1: highest bidder in group 1
         * qOB2: quantity of buyers in group 2
         * hb2: highest bidder in group 2
         * mC: Marginal cost */
        
        //counter for error message loop
        int shameCounter = 0;
        string[] errorTitles = { "Oopsies", "Ouch!", "Whoopsie-Daisies!", "uh-oh!", "Yikes!", "Shoot!", "Crud!", "Dang!", "Oh heck!", "Rats!" };
        System.Windows.Forms.TextBox[] textInputs = new System.Windows.Forms.TextBox[5];

        public frmMainMenu()
        {
            InitializeComponent();
            // initializes the text boxes into the textInputs array
            textInputs[0] = txtQH1;
            textInputs[1] = txtQH2;
            textInputs[2] = txtAH1;
            textInputs[3] = txtAH2;
            textInputs[4] = txtMC;
        }

        public bool DoesNotContainDecimal(System.Windows.Forms.TextBox textBox, string name)
        {

            //if (Int32.TryParse(textBox.Text, out int number))
            if (!textBox.Text.Contains("."))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be a whole number.", errorTitles[shameCounter]);
                textBox.SelectionStart = 0;
                textBox.SelectionLength = textBox.Text.Length;
                textBox.Focus();
                textBox.Text = "";
                if (shameCounter < errorTitles.Length - 1)
                {
                    shameCounter++;

                }
                else
                {
                    shameCounter = 0;
                }

                return false;

            }
        }

        /* I've decided to impliment real time event handling to minimize backtracking
         * while entering values
         * 
         * The Save Values events works as such:
         * As the user enters values into the textboxes, the values save into the static string variables
           This happens in real time
           As values are entered, the exception heiarchy runs to make sure that the user does not enter an inappropriate value
           Exception handling is appropriate here as we want our stings to be valid numbers
         */
        private void SaveValuesQH1(object sender, EventArgs e)
        {
            //regarding the exceptions handling: first we test the string
            if (txtQH1.Text != "")
            {
                try
                {
                    decimal test = Convert.ToDecimal(txtQH1.Text);
                }
                //then we throw an exception if a charactar is entered
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values", errorTitles[shameCounter]);
                    //we set the txt to 0 as entering a null value will throw a format exception
                    //we choose zero for theoretical stress testing purposes
                    txtQH1.Text = "";
                    //we want to select "0" for user convienience
                    //the variable is reset
                    qOB1 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                //if the number is too big, we throw another exception

                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[shameCounter]);
                    txtQH1.Text = "";
                    qOB1 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                //Finally, we set the string variable to the valid number

                finally
                {
                    qOB1 = txtQH1.Text;
                }
            }
        }
        //The following events are identical to the first
        private void SaveValuesAH1(object sender, EventArgs e)
        {
            if (txtAH1.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH1.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[shameCounter]);
                    txtAH1.Text = "";
                    hB1 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[shameCounter]);
                    txtAH1.Text = "";
                    hB1 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                finally
                {
                    hB1 = txtAH1.Text;
                }
        }
        private void SaveValuesQH2(object sender, EventArgs e)
        {

            if (txtQH2.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtQH2.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values", errorTitles[shameCounter]);
                    txtQH2.Text = "";
                    qOB2 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[shameCounter]);
                    txtQH2.Text = "";
                    qOB2 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                finally
                {
                    qOB2 = txtQH2.Text;
                }
        }

        private void SaveValuesAH2(object sender, EventArgs e)
        {
            if (txtAH2.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH2.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[shameCounter]);
                    txtAH2.Text = "";
                    hB2 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                //Error message for user entering a number that is too big for the calculation
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[shameCounter]);
                    txtAH2.Text = "";
                    hB2 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                finally
                {
                    hB2 = txtAH2.Text;
                }
        }

        private void SaveValuesMC(object sender, EventArgs e)
        {
            if (txtMC.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtMC.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Please do not use non-number values unless you are entering a decimal number", errorTitles[shameCounter]);
                    txtMC.Text = "";
                    mC = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Too many numbers! Please enter smaller values.", errorTitles[shameCounter]);
                    txtMC.Text = "";
                    mC = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                finally
                {
                    mC = txtMC.Text;
                }
        }

        //The next set of events trigger when you tab away from a text box
        //if and only if a zero is entered when you tab away, a divide by zero exception will trigger
        //There are multiple calculations where dividing by zero can occur in the app. Applying this rule to the inputs will prevent this from happening
        private void LeaveQH1(object sender, EventArgs e)
        {
            //we trigger a divide by zero by turning the string into a test variable, then putting that test variable in a denominator

            //we've created a doorway so that you mustn't have a null to proceed to the exception handling
            if (txtQH1.Text != "")
                try
                {
                    DoesNotContainDecimal(txtQH1, "Quantity of Buyers");
                    //we've created another so we can null a violation of the validation while not passing the null value to check for a zero value
                    if (txtQH1.Text != "")
                    {
                        decimal test = Convert.ToDecimal(txtQH1.Text);
                        decimal zeroTest = 1 / test;
                    }
                }
                //we need a format exception exception since tabbing without entering a value will crash the program (null is not a numeric value)
                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[shameCounter]);
                    txtQH1.Text = "";
                    txtQH1.Focus();
                    qOB1 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }
                finally
                {
                    //decimal trunk = Convert.ToDecimal(txtQH1.Text);
                    //Math.Truncate(trunk);
                    //txtQH1.Text = Convert.ToString(trunk);
                    qOB1 = txtQH1.Text;
                }

        }
        private void LeaveAH1(object sender, EventArgs e)
        {
            if (txtAH1.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH1.Text);
                    decimal zeroTest = 1 / test;
                }

                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[shameCounter]);
                    txtAH1.Text = "";
                    txtAH1.Focus();
                    hB1 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }

                finally
                {
                    hB1 = txtAH1.Text;
                }
        }
        private void LeaveQH2(object sender, EventArgs e)
        {
            if (txtQH2.Text != "")
                try
                {
                    DoesNotContainDecimal(txtQH2, "Quantity of Buyers");
                    if (txtQH2.Text != "")
                    {
                        decimal test = Convert.ToDecimal(txtQH2.Text);
                        decimal zeroTest = 1 / test;
                    }
                }
                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[shameCounter]);
                    txtQH2.Text = "";
                    txtQH2.Focus();
                    qOB2 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }

                finally
                {
                   
                   
                        qOB2 = txtQH2.Text;
                  
                }
        }
        private void LeaveAH2(object sender, EventArgs e)
        {
            if (txtAH2.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtAH2.Text);
                    decimal zeroTest = 1 / test;
                }

                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[shameCounter]);
                    txtAH2.Text = "";
                    txtAH2.Focus();
                    hB2 = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }

                finally
                {
                    hB2 = txtAH2.Text;
                }
        }
        private void LeaveMC(object sender, EventArgs e)
        {
            if (txtMC.Text != "")
                try
                {
                    decimal test = Convert.ToDecimal(txtMC.Text);
                    decimal zeroTest = 1 / test;
                }

                catch (DivideByZeroException)
                {
                    MessageBox.Show("You cannot enter a quantity of zero as you will be dividing with this", errorTitles[shameCounter]);
                    txtMC.Text = "";
                    txtMC.Focus();
                    mC = "";
                    if (shameCounter < errorTitles.Length - 1)
                    {
                        shameCounter++;

                    }
                    else
                    {
                        shameCounter = 0;
                    }
                }

                finally
                {
                    mC = txtMC.Text;
                }
        }

        //null values are perferred, but a null string will cause an exception due to the test variable creating a format exception
        

        private void btnClear_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < textInputs.Length; i++)
            {
                textInputs[i].Clear();
            }
        }

        //Clicking on any of these first five buttons launch their subsequent pricing calculators
        private void btnMonopolisticPricing_Click(object sender, EventArgs e)
        {
            frmMonopolisticPricing mp = new frmMonopolisticPricing();
            mp.ShowDialog();
        }

        private void btnNonGroupPricing_Click(object sender, EventArgs e)
        {
            frmNonGroupPricing ngp = new frmNonGroupPricing();
            ngp.ShowDialog();
        }

        private void btnGroupPricing_Click(object sender, EventArgs e)
        {
            frmGroupPricing gp = new frmGroupPricing();
            gp.ShowDialog();
        }

        private void btnMenuPricing_Click(object sender, EventArgs e)
        {
            frmMenuPricing mp = new frmMenuPricing();
            mp.ShowDialog();
        }

        private void btnPersonalizedPricing_Click(object sender, EventArgs e)
        {
            frmPersonalizedPricing pp = new frmPersonalizedPricing();
            pp.ShowDialog();
        }

        private void btnBlockPricing_Click(object sender, EventArgs e)
        {
            frmBlockPricing bp = new frmBlockPricing();
            bp.ShowDialog();
        }

        private void btnProfitComparison_Click(object sender, EventArgs e)
        {
            frmProfitComparison pc = new frmProfitComparison();
            pc.ShowDialog();
        }

        //This form acts as an encyclopedia of popups explaining what the main menu does
        private void btnHelp_Click(object sender, EventArgs e)
        {
            frmHelp help = new frmHelp();
            help.ShowDialog();
        }
        //This form gives project info and the version (always 1.0)
        private void btnAbout_Click(object sender, EventArgs e)
        {
            frmAbout about = new frmAbout();
            about.ShowDialog();
        }
        //Exit the application
        private void btnLeave_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
