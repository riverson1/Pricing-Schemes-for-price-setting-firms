﻿namespace Pricing_Schemes_for_Price_Setting_Firms
{
    partial class frmPersonalizedPricing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.txtAH2 = new System.Windows.Forms.TextBox();
            this.txtQH2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFMC = new System.Windows.Forms.Label();
            this.txtMC = new System.Windows.Forms.TextBox();
            this.btnFindOptimalPrice = new System.Windows.Forms.Button();
            this.txtAH1 = new System.Windows.Forms.TextBox();
            this.txtQH1 = new System.Windows.Forms.TextBox();
            this.lblHB = new System.Windows.Forms.Label();
            this.lblQOB = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtOptimalPPU2 = new System.Windows.Forms.TextBox();
            this.txtOptimalPPU1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtProfit2 = new System.Windows.Forms.TextBox();
            this.txtProfit1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtProfit = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Location = new System.Drawing.Point(644, 400);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // txtAH2
            // 
            this.txtAH2.Location = new System.Drawing.Point(604, 121);
            this.txtAH2.Name = "txtAH2";
            this.txtAH2.Size = new System.Drawing.Size(100, 22);
            this.txtAH2.TabIndex = 5;
            this.txtAH2.TextChanged += new System.EventHandler(this.ChangeTextAH2);
            this.txtAH2.Leave += new System.EventHandler(this.LeaveAH2);
            // 
            // txtQH2
            // 
            this.txtQH2.AcceptsTab = true;
            this.txtQH2.Location = new System.Drawing.Point(604, 58);
            this.txtQH2.Name = "txtQH2";
            this.txtQH2.Size = new System.Drawing.Size(100, 22);
            this.txtQH2.TabIndex = 4;
            this.txtQH2.TextChanged += new System.EventHandler(this.ChangeTextQH2);
            this.txtQH2.Leave += new System.EventHandler(this.LeaveQH2);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(478, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 56;
            this.label2.Text = "Highest Bidder";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(460, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 16);
            this.label3.TabIndex = 55;
            this.label3.Text = "Quantity of Buyers";
            // 
            // lblFMC
            // 
            this.lblFMC.AutoSize = true;
            this.lblFMC.Location = new System.Drawing.Point(85, 174);
            this.lblFMC.Name = "lblFMC";
            this.lblFMC.Size = new System.Drawing.Size(125, 16);
            this.lblFMC.TabIndex = 54;
            this.lblFMC.Text = "Fixed Marginal Cost";
            // 
            // txtMC
            // 
            this.txtMC.Location = new System.Drawing.Point(233, 171);
            this.txtMC.Name = "txtMC";
            this.txtMC.Size = new System.Drawing.Size(100, 22);
            this.txtMC.TabIndex = 3;
            this.txtMC.TextChanged += new System.EventHandler(this.ChangeTextMC);
            // 
            // btnFindOptimalPrice
            // 
            this.btnFindOptimalPrice.Location = new System.Drawing.Point(332, 227);
            this.btnFindOptimalPrice.Name = "btnFindOptimalPrice";
            this.btnFindOptimalPrice.Size = new System.Drawing.Size(169, 23);
            this.btnFindOptimalPrice.TabIndex = 0;
            this.btnFindOptimalPrice.Text = "Find Optimal Price";
            this.btnFindOptimalPrice.UseVisualStyleBackColor = true;
            this.btnFindOptimalPrice.Click += new System.EventHandler(this.btnFindOptimalPrice_Click);
            // 
            // txtAH1
            // 
            this.txtAH1.Location = new System.Drawing.Point(233, 118);
            this.txtAH1.Name = "txtAH1";
            this.txtAH1.Size = new System.Drawing.Size(100, 22);
            this.txtAH1.TabIndex = 2;
            this.txtAH1.TextChanged += new System.EventHandler(this.ChangeTextAH1);
            this.txtAH1.Leave += new System.EventHandler(this.LeaveAH1);
            // 
            // txtQH1
            // 
            this.txtQH1.AcceptsTab = true;
            this.txtQH1.Location = new System.Drawing.Point(233, 64);
            this.txtQH1.Name = "txtQH1";
            this.txtQH1.Size = new System.Drawing.Size(100, 22);
            this.txtQH1.TabIndex = 1;
            this.txtQH1.TextChanged += new System.EventHandler(this.ChangeTextQH1);
            this.txtQH1.Leave += new System.EventHandler(this.LeaveQH1);
            // 
            // lblHB
            // 
            this.lblHB.AutoSize = true;
            this.lblHB.Location = new System.Drawing.Point(114, 121);
            this.lblHB.Name = "lblHB";
            this.lblHB.Size = new System.Drawing.Size(96, 16);
            this.lblHB.TabIndex = 52;
            this.lblHB.Text = "Highest Bidder";
            // 
            // lblQOB
            // 
            this.lblQOB.AutoSize = true;
            this.lblQOB.Location = new System.Drawing.Point(96, 64);
            this.lblQOB.Name = "lblQOB";
            this.lblQOB.Size = new System.Drawing.Size(114, 16);
            this.lblQOB.TabIndex = 51;
            this.lblQOB.Text = "Quantity of Buyers";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(414, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 16);
            this.label6.TabIndex = 64;
            this.label6.Text = "Optimal Per Unit Price Group 2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 287);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(187, 16);
            this.label7.TabIndex = 63;
            this.label7.Text = "Optimal Per Unit Price Group 1";
            // 
            // txtOptimalPPU2
            // 
            this.txtOptimalPPU2.Location = new System.Drawing.Point(631, 284);
            this.txtOptimalPPU2.Name = "txtOptimalPPU2";
            this.txtOptimalPPU2.ReadOnly = true;
            this.txtOptimalPPU2.Size = new System.Drawing.Size(100, 22);
            this.txtOptimalPPU2.TabIndex = 62;
            this.txtOptimalPPU2.TabStop = false;
            // 
            // txtOptimalPPU1
            // 
            this.txtOptimalPPU1.Location = new System.Drawing.Point(257, 284);
            this.txtOptimalPPU1.Name = "txtOptimalPPU1";
            this.txtOptimalPPU1.ReadOnly = true;
            this.txtOptimalPPU1.Size = new System.Drawing.Size(100, 22);
            this.txtOptimalPPU1.TabIndex = 61;
            this.txtOptimalPPU1.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(421, 328);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(180, 16);
            this.label8.TabIndex = 68;
            this.label8.Text = "Entry Price and Profit Group 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(41, 328);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(180, 16);
            this.label9.TabIndex = 67;
            this.label9.Text = "Entry Price and Profit Group 1";
            // 
            // txtProfit2
            // 
            this.txtProfit2.Location = new System.Drawing.Point(631, 325);
            this.txtProfit2.Name = "txtProfit2";
            this.txtProfit2.ReadOnly = true;
            this.txtProfit2.Size = new System.Drawing.Size(100, 22);
            this.txtProfit2.TabIndex = 66;
            this.txtProfit2.TabStop = false;
            // 
            // txtProfit1
            // 
            this.txtProfit1.Location = new System.Drawing.Point(257, 325);
            this.txtProfit1.Name = "txtProfit1";
            this.txtProfit1.ReadOnly = true;
            this.txtProfit1.Size = new System.Drawing.Size(100, 22);
            this.txtProfit1.TabIndex = 65;
            this.txtProfit1.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(286, 404);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 69;
            this.label10.Text = "Total Profit";
            // 
            // txtProfit
            // 
            this.txtProfit.Location = new System.Drawing.Point(424, 401);
            this.txtProfit.Name = "txtProfit";
            this.txtProfit.ReadOnly = true;
            this.txtProfit.Size = new System.Drawing.Size(100, 22);
            this.txtProfit.TabIndex = 70;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(59, 400);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmPersonalizedPricing
            // 
            this.AcceptButton = this.btnFindOptimalPrice;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnBack;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtProfit);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtProfit2);
            this.Controls.Add(this.txtProfit1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtOptimalPPU2);
            this.Controls.Add(this.txtOptimalPPU1);
            this.Controls.Add(this.txtAH2);
            this.Controls.Add(this.txtQH2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblFMC);
            this.Controls.Add(this.txtMC);
            this.Controls.Add(this.btnFindOptimalPrice);
            this.Controls.Add(this.txtAH1);
            this.Controls.Add(this.txtQH1);
            this.Controls.Add(this.lblHB);
            this.Controls.Add(this.lblQOB);
            this.Controls.Add(this.btnBack);
            this.Name = "frmPersonalizedPricing";
            this.Text = "Two-Part Tariff";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox txtAH2;
        private System.Windows.Forms.TextBox txtQH2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblFMC;
        private System.Windows.Forms.TextBox txtMC;
        private System.Windows.Forms.Button btnFindOptimalPrice;
        private System.Windows.Forms.TextBox txtAH1;
        private System.Windows.Forms.TextBox txtQH1;
        private System.Windows.Forms.Label lblHB;
        private System.Windows.Forms.Label lblQOB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtOptimalPPU2;
        private System.Windows.Forms.TextBox txtOptimalPPU1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtProfit2;
        private System.Windows.Forms.TextBox txtProfit1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtProfit;
        private System.Windows.Forms.Button btnClear;
    }
}