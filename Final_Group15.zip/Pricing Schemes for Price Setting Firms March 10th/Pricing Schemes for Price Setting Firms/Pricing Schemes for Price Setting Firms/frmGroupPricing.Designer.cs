﻿namespace Pricing_Schemes_for_Price_Setting_Firms
{
    partial class frmGroupPricing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.lblFMC = new System.Windows.Forms.Label();
            this.txtMC = new System.Windows.Forms.TextBox();
            this.txtOptimalPrice1 = new System.Windows.Forms.TextBox();
            this.btnFindOptimalPrice = new System.Windows.Forms.Button();
            this.txtAH1 = new System.Windows.Forms.TextBox();
            this.txtQH1 = new System.Windows.Forms.TextBox();
            this.lblHB = new System.Windows.Forms.Label();
            this.lblQOB = new System.Windows.Forms.Label();
            this.txtAH2 = new System.Windows.Forms.TextBox();
            this.txtQH2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOptimalPrice2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtProfit = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtProfit2 = new System.Windows.Forms.TextBox();
            this.txtProfit1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Location = new System.Drawing.Point(679, 404);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 8;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblFMC
            // 
            this.lblFMC.AutoSize = true;
            this.lblFMC.Location = new System.Drawing.Point(241, 185);
            this.lblFMC.Name = "lblFMC";
            this.lblFMC.Size = new System.Drawing.Size(125, 16);
            this.lblFMC.TabIndex = 34;
            this.lblFMC.Text = "Fixed Marginal Cost";
            // 
            // txtMC
            // 
            this.txtMC.Location = new System.Drawing.Point(403, 179);
            this.txtMC.Name = "txtMC";
            this.txtMC.Size = new System.Drawing.Size(100, 22);
            this.txtMC.TabIndex = 5;
            this.txtMC.TextChanged += new System.EventHandler(this.ChangeTextMC);
            // 
            // txtOptimalPrice1
            // 
            this.txtOptimalPrice1.Location = new System.Drawing.Point(198, 291);
            this.txtOptimalPrice1.Name = "txtOptimalPrice1";
            this.txtOptimalPrice1.ReadOnly = true;
            this.txtOptimalPrice1.Size = new System.Drawing.Size(100, 22);
            this.txtOptimalPrice1.TabIndex = 32;
            this.txtOptimalPrice1.TabStop = false;
            // 
            // btnFindOptimalPrice
            // 
            this.btnFindOptimalPrice.Location = new System.Drawing.Point(276, 243);
            this.btnFindOptimalPrice.Name = "btnFindOptimalPrice";
            this.btnFindOptimalPrice.Size = new System.Drawing.Size(169, 23);
            this.btnFindOptimalPrice.TabIndex = 0;
            this.btnFindOptimalPrice.Text = "Find Optimal Price";
            this.btnFindOptimalPrice.UseVisualStyleBackColor = true;
            this.btnFindOptimalPrice.Click += new System.EventHandler(this.btnFindOptimalPrice_Click);
            // 
            // txtAH1
            // 
            this.txtAH1.Location = new System.Drawing.Point(180, 120);
            this.txtAH1.Name = "txtAH1";
            this.txtAH1.Size = new System.Drawing.Size(100, 22);
            this.txtAH1.TabIndex = 2;
            this.txtAH1.TextChanged += new System.EventHandler(this.ChangeTextAH1);
            this.txtAH1.Leave += new System.EventHandler(this.LeaveAH1);
            // 
            // txtQH1
            // 
            this.txtQH1.AcceptsTab = true;
            this.txtQH1.Location = new System.Drawing.Point(180, 72);
            this.txtQH1.Name = "txtQH1";
            this.txtQH1.Size = new System.Drawing.Size(100, 22);
            this.txtQH1.TabIndex = 1;
            this.txtQH1.TextChanged += new System.EventHandler(this.ChangeTextQH1);
            this.txtQH1.Leave += new System.EventHandler(this.LeaveQH1);
            // 
            // lblHB
            // 
            this.lblHB.AutoSize = true;
            this.lblHB.Location = new System.Drawing.Point(61, 126);
            this.lblHB.Name = "lblHB";
            this.lblHB.Size = new System.Drawing.Size(96, 16);
            this.lblHB.TabIndex = 29;
            this.lblHB.Text = "Highest Bidder";
            // 
            // lblQOB
            // 
            this.lblQOB.AutoSize = true;
            this.lblQOB.Location = new System.Drawing.Point(43, 72);
            this.lblQOB.Name = "lblQOB";
            this.lblQOB.Size = new System.Drawing.Size(114, 16);
            this.lblQOB.TabIndex = 28;
            this.lblQOB.Text = "Quantity of Buyers";
            // 
            // txtAH2
            // 
            this.txtAH2.Location = new System.Drawing.Point(551, 126);
            this.txtAH2.Name = "txtAH2";
            this.txtAH2.Size = new System.Drawing.Size(100, 22);
            this.txtAH2.TabIndex = 4;
            this.txtAH2.TextChanged += new System.EventHandler(this.ChangeTextAH2);
            this.txtAH2.Leave += new System.EventHandler(this.LeaveAH2);
            // 
            // txtQH2
            // 
            this.txtQH2.AcceptsTab = true;
            this.txtQH2.Location = new System.Drawing.Point(551, 72);
            this.txtQH2.Name = "txtQH2";
            this.txtQH2.Size = new System.Drawing.Size(100, 22);
            this.txtQH2.TabIndex = 3;
            this.txtQH2.TextChanged += new System.EventHandler(this.ChangeTextQH2);
            this.txtQH2.Leave += new System.EventHandler(this.LeaveQH2);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(425, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 36;
            this.label2.Text = "Highest Bidder";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(407, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 16);
            this.label3.TabIndex = 35;
            this.label3.Text = "Quantity of Buyers";
            // 
            // txtOptimalPrice2
            // 
            this.txtOptimalPrice2.Location = new System.Drawing.Point(583, 294);
            this.txtOptimalPrice2.Name = "txtOptimalPrice2";
            this.txtOptimalPrice2.ReadOnly = true;
            this.txtOptimalPrice2.Size = new System.Drawing.Size(100, 22);
            this.txtOptimalPrice2.TabIndex = 41;
            this.txtOptimalPrice2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 297);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 16);
            this.label4.TabIndex = 42;
            this.label4.Text = "Optimal Price Group 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(420, 297);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 16);
            this.label5.TabIndex = 43;
            this.label5.Text = "Optimal Price Group 2";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(33, 404);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 71;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtProfit
            // 
            this.txtProfit.Location = new System.Drawing.Point(410, 398);
            this.txtProfit.Name = "txtProfit";
            this.txtProfit.ReadOnly = true;
            this.txtProfit.Size = new System.Drawing.Size(100, 22);
            this.txtProfit.TabIndex = 73;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(317, 404);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 72;
            this.label10.Text = "Total Profit";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(407, 348);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 16);
            this.label8.TabIndex = 77;
            this.label8.Text = "Estimated Profit Group 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 348);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(150, 16);
            this.label9.TabIndex = 76;
            this.label9.Text = "Estimated Profit Group 1";
            // 
            // txtProfit2
            // 
            this.txtProfit2.Location = new System.Drawing.Point(583, 342);
            this.txtProfit2.Name = "txtProfit2";
            this.txtProfit2.ReadOnly = true;
            this.txtProfit2.Size = new System.Drawing.Size(100, 22);
            this.txtProfit2.TabIndex = 75;
            this.txtProfit2.TabStop = false;
            // 
            // txtProfit1
            // 
            this.txtProfit1.Location = new System.Drawing.Point(198, 342);
            this.txtProfit1.Name = "txtProfit1";
            this.txtProfit1.ReadOnly = true;
            this.txtProfit1.Size = new System.Drawing.Size(100, 22);
            this.txtProfit1.TabIndex = 74;
            this.txtProfit1.TabStop = false;
            // 
            // frmGroupPricing
            // 
            this.AcceptButton = this.btnFindOptimalPrice;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnBack;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtProfit2);
            this.Controls.Add(this.txtProfit1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtProfit);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtOptimalPrice2);
            this.Controls.Add(this.txtAH2);
            this.Controls.Add(this.txtQH2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblFMC);
            this.Controls.Add(this.txtMC);
            this.Controls.Add(this.txtOptimalPrice1);
            this.Controls.Add(this.btnFindOptimalPrice);
            this.Controls.Add(this.txtAH1);
            this.Controls.Add(this.txtQH1);
            this.Controls.Add(this.lblHB);
            this.Controls.Add(this.lblQOB);
            this.Controls.Add(this.btnBack);
            this.Name = "frmGroupPricing";
            this.Text = "Group Pricing";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblFMC;
        private System.Windows.Forms.TextBox txtMC;
        private System.Windows.Forms.TextBox txtOptimalPrice1;
        private System.Windows.Forms.Button btnFindOptimalPrice;
        private System.Windows.Forms.TextBox txtAH1;
        private System.Windows.Forms.TextBox txtQH1;
        private System.Windows.Forms.Label lblHB;
        private System.Windows.Forms.Label lblQOB;
        private System.Windows.Forms.TextBox txtAH2;
        private System.Windows.Forms.TextBox txtQH2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtOptimalPrice2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtProfit;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtProfit2;
        private System.Windows.Forms.TextBox txtProfit1;
    }
}