﻿namespace Pricing_Schemes_for_Price_Setting_Firms
{
    partial class frmMonopolisticPricing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFMC = new System.Windows.Forms.Label();
            this.txtMC = new System.Windows.Forms.TextBox();
            this.txtOptimalPrice = new System.Windows.Forms.TextBox();
            this.btnFindOptimalPrice = new System.Windows.Forms.Button();
            this.txtAH = new System.Windows.Forms.TextBox();
            this.txtQH = new System.Windows.Forms.TextBox();
            this.lblHB = new System.Windows.Forms.Label();
            this.lblQOB = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtProfit = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblFMC
            // 
            this.lblFMC.AutoSize = true;
            this.lblFMC.Location = new System.Drawing.Point(258, 193);
            this.lblFMC.Name = "lblFMC";
            this.lblFMC.Size = new System.Drawing.Size(125, 16);
            this.lblFMC.TabIndex = 25;
            this.lblFMC.Text = "Fixed Marginal Cost";
            // 
            // txtMC
            // 
            this.txtMC.Location = new System.Drawing.Point(433, 193);
            this.txtMC.Name = "txtMC";
            this.txtMC.Size = new System.Drawing.Size(100, 22);
            this.txtMC.TabIndex = 3;
            this.txtMC.TextChanged += new System.EventHandler(this.TextChangedMC);
            // 
            // txtOptimalPrice
            // 
            this.txtOptimalPrice.Location = new System.Drawing.Point(433, 292);
            this.txtOptimalPrice.Name = "txtOptimalPrice";
            this.txtOptimalPrice.ReadOnly = true;
            this.txtOptimalPrice.Size = new System.Drawing.Size(100, 22);
            this.txtOptimalPrice.TabIndex = 23;
            this.txtOptimalPrice.TabStop = false;
            // 
            // btnFindOptimalPrice
            // 
            this.btnFindOptimalPrice.Location = new System.Drawing.Point(232, 292);
            this.btnFindOptimalPrice.Name = "btnFindOptimalPrice";
            this.btnFindOptimalPrice.Size = new System.Drawing.Size(169, 23);
            this.btnFindOptimalPrice.TabIndex = 4;
            this.btnFindOptimalPrice.Text = "Find Optimal Price";
            this.btnFindOptimalPrice.UseVisualStyleBackColor = true;
            this.btnFindOptimalPrice.Click += new System.EventHandler(this.btnFindOptimalPrice_Click);
            // 
            // txtAH
            // 
            this.txtAH.Location = new System.Drawing.Point(433, 143);
            this.txtAH.Name = "txtAH";
            this.txtAH.Size = new System.Drawing.Size(100, 22);
            this.txtAH.TabIndex = 2;
            this.txtAH.TextChanged += new System.EventHandler(this.TextChangedAH);
            this.txtAH.Leave += new System.EventHandler(this.LeaveAH);
            // 
            // txtQH
            // 
            this.txtQH.AcceptsTab = true;
            this.txtQH.Location = new System.Drawing.Point(433, 95);
            this.txtQH.Name = "txtQH";
            this.txtQH.Size = new System.Drawing.Size(100, 22);
            this.txtQH.TabIndex = 1;
            this.txtQH.TextChanged += new System.EventHandler(this.TextChangedQH);
            this.txtQH.Leave += new System.EventHandler(this.LeaveQH);
            // 
            // lblHB
            // 
            this.lblHB.AutoSize = true;
            this.lblHB.Location = new System.Drawing.Point(287, 146);
            this.lblHB.Name = "lblHB";
            this.lblHB.Size = new System.Drawing.Size(96, 16);
            this.lblHB.TabIndex = 18;
            this.lblHB.Text = "Highest Bidder";
            // 
            // lblQOB
            // 
            this.lblQOB.AutoSize = true;
            this.lblQOB.Location = new System.Drawing.Point(269, 95);
            this.lblQOB.Name = "lblQOB";
            this.lblQOB.Size = new System.Drawing.Size(114, 16);
            this.lblQOB.TabIndex = 17;
            this.lblQOB.Text = "Quantity of Buyers";
            // 
            // btnBack
            // 
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBack.Location = new System.Drawing.Point(688, 380);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(42, 380);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtProfit
            // 
            this.txtProfit.Location = new System.Drawing.Point(433, 380);
            this.txtProfit.Name = "txtProfit";
            this.txtProfit.ReadOnly = true;
            this.txtProfit.Size = new System.Drawing.Size(100, 22);
            this.txtProfit.TabIndex = 73;
            this.txtProfit.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(287, 383);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 16);
            this.label10.TabIndex = 72;
            this.label10.Text = "Total Profit";
            // 
            // frmMonopolisticPricing
            // 
            this.AcceptButton = this.btnFindOptimalPrice;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnBack;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txtProfit);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblFMC);
            this.Controls.Add(this.txtMC);
            this.Controls.Add(this.txtOptimalPrice);
            this.Controls.Add(this.btnFindOptimalPrice);
            this.Controls.Add(this.txtAH);
            this.Controls.Add(this.txtQH);
            this.Controls.Add(this.lblHB);
            this.Controls.Add(this.lblQOB);
            this.Controls.Add(this.btnBack);
            this.Name = "frmMonopolisticPricing";
            this.Text = "Aggregated Pricing";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFMC;
        private System.Windows.Forms.TextBox txtMC;
        private System.Windows.Forms.TextBox txtOptimalPrice;
        private System.Windows.Forms.Button btnFindOptimalPrice;
        private System.Windows.Forms.TextBox txtAH;
        private System.Windows.Forms.TextBox txtQH;
        private System.Windows.Forms.Label lblHB;
        private System.Windows.Forms.Label lblQOB;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtProfit;
        private System.Windows.Forms.Label label10;
    }
}